/* 74LS164.c */
#include "defines.h"
#include "delay.h"
#include <LPC21xx.h>


#define SIN0  16     //p0.8
#define CP0   17    //p0.9
#define SIN1  18    //p0.10
#define CP1   19 	//p0.11
#define SIN2  20    //p0.12
#define CP2   21 	//p0.13
#define SIN3  22    //p0.14
#define CP3   23 	//p0.15


void Init_74LS164(void)
{
        /*IODIR0|= (1<<CP0|1<<SIN0);
        IODIR0|= (1<<CP1|1<<SIN1);
        IODIR0|= (1<<CP2|1<<SIN2);
        IODIR0|= (1<<CP3|1<<SIN3); */
		IODIR1|=255<<SIN0;
}

void SIPO_74LS164(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   //SCLRBIT(IOCLR0,_MR);
   //delay_us(1);
   //SSETBIT(IOSET0,_MR);
   //delay_us(1);

   for(i=0;i<8;i++)
   {

                   WRITEBIT(IOPIN1,SIN0,((sDat>>(7-i))&1));
                   SSETBIT(IOSET1,CP0);
                   delay_us(1);
                   SCLRBIT(IOCLR1,CP0);
                   delay_us(1);
   }
}
void SIPO_74LS1641(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   //SCLRBIT(IOCLR0,_MR);
   //delay_us(1);
   //SSETBIT(IOSET0,_MR);
   //delay_us(1);

   for(i=0;i<8;i++)
   {
                            WRITEBIT(IOPIN1,SIN1,((sDat>>(7-i))&1));
                            SSETBIT(IOSET1,CP1);
                            delay_us(1);
                            SCLRBIT(IOCLR1,CP1);
                            delay_us(1);
        }
}
void SIPO_74LS1642(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   //SCLRBIT(IOCLR0,_MR);
   //delay_us(1);
   //SSETBIT(IOSET0,_MR);
   //delay_us(1);

   for(i=0;i<8;i++)
   {
                            WRITEBIT(IOPIN1,SIN2,((sDat>>(7-i))&1));
                           SSETBIT(IOSET1,CP2);
                           delay_us(1);
                           SCLRBIT(IOCLR1,CP2);
                           delay_us(1);
   }
}
void SIPO_74LS1643(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   //SCLRBIT(IOCLR0,_MR);
   //delay_us(1);
   //SSETBIT(IOSET0,_MR);
   //delay_us(1);

   for(i=0;i<8;i++)
   {
                    WRITEBIT(IOPIN1,SIN3,((sDat>>(7-i))&1));
                   SSETBIT(IOSET1,CP3);
                   delay_us(1);
                   SCLRBIT(IOCLR1,CP3);
                   delay_us(1);
        }
}



