#include<lpc21xx.h>
#include <string.h>
#include"delay.h"
#include"types.h"
//#include"lcd_defines.h"
//#include "lcd.h"
#include "i2c.h"
#include "i2c_defines.h"
#include "i2c_eeprom.h"
#include "uart_interrupt.h"

#include "74LS164.h"
#include "dml.h"
#define I2C_EEPROM_SA 0x0050
#define ADDRR 0x0000
extern char i,r_flag;
char dummy_buff[100];
extern char buff[100],l;
unsigned char  j=0;
char temp[6];
char passkey[]="@@786";
char wrong[]="   WRONG PASSKEY   "; 
int main()
{ 
	char k[100]="   DYNAMIC E-NOTICE BOARD   ";
	  init_i2c();
	  Init_74LS164();
	  InitUART0();
	  i=0;r_flag=0,j=0;    
    IODIR0 |= 0x00ff0000; //ROWS as output    
    l=strlen(k);
    i2c_eeprom_page_write(I2C_EEPROM_SA,ADDRR,(u8*)k,l);
    i2c_eeprom_seq_read(I2C_EEPROM_SA,ADDRR,(u8*)dummy_buff,l);
    while(1)
  	{
		
		do
		{
		   display_char((unsigned char*)dummy_buff,1700);
		}while(r_flag==0);
		r_flag=0;
		j=0;
		while(j<5)
		{
			temp[j]=buff[j];
			j++;
		}
		temp[j]='\0';
		l=strlen(buff);
		buff[2]=32;
		buff[3]=32;
		buff[4]=32;
		buff[l++]=32;								
		buff[l++]=32;
		buff[l]=32;
		l=strlen(buff);
		memset(dummy_buff,'\0',100);
		UART0_Str(buff);
		if((strcmp(temp,passkey))==0)
		{
			l=strlen(buff+j);
			i2c_eeprom_page_write(I2C_EEPROM_SA,ADDRR,(u8*)buff+2,l);
			delay_ms(1000);
			i2c_eeprom_seq_read(I2C_EEPROM_SA,ADDRR,(u8*)dummy_buff,l);
			dummy_buff[l++]=32;
			dummy_buff[l++]=32;
			dummy_buff[l++]=32;
			dummy_buff[l]='\0';
			UART0_Str(dummy_buff);
		}
		else
		{
			display_char((unsigned char *)wrong,1700);
		}
		r_flag=0;
		memset(buff,'\0',100);
		memset(temp,'\0',6);
		j=0,l=0;
		i=0;
	}            
}

