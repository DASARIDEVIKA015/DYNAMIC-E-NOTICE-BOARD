#include "delay.h"

#include "uart.h"
extern char buff[50];

extern unsigned char i,r_flag,t_flag;

int pass_key=0;
char buff1[]="wrong passkey";                                                   ^M

int main()
{               int len=0;

  InitUART0();



                i=0;r_flag = 0;

                /*do

                {

                        UART0_Str("V24HE1 BATCH\r\n");

                        delay_ms(1000);

                }*/
                while(r_flag==0);

                UART0_Str("Received string is: ");

                UART0_Str(buff);

                UART0_Str("\r\n");
                len=strlen(buff);
                 if(buff[0]=='@')
                {
                        if(buff[1]=='@'&&buff[2]=='786')
                        {
                                i=2;
                                while(i<=5)
                                {
                                pass_key=(pass_key*10)+(buff[i]-48);
                                i++;
                            }
                                if(pass_key==8765)
                                        {
                                        i=7;
                                        while(buff[i])
                                        {
                                        UART0_Tx(buff[i]);
                                        i++;
                                        }^M
                                        }^M
                                        else
                                                UART0_Str(buff1);
                        }


                }

}

       
