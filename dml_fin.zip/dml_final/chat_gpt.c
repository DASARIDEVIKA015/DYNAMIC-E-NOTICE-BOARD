					 #include <lpc21xx.h>
#include <string.h>
#include "delay.h"
#include "types.h"
#include "i2c.h"
#include "i2c_defines.h"
#include "i2c_eeprom.h"
#include "uart_interrupt.h"
#include "74LS164.h"
#include "dml.h"

#define I2C_EEPROM_SA  0x0050
#define ADDRR          0x0000

extern char r_flag;
extern char buff[100], l;
char dummy_buff[100];

void clear_buffer(char *buffer, int size) {
    memset(buffer, '\0', size);
}

int main() { 
    unsigned char received_data[100];// Buffer to hold incoming UART data
	int len;
	char k[100]="   DYNAMIC E-NOTICE BOARD   ";
	init_i2c();
	  Init_74LS164();
	  InitUART0();
	r_flag=0;   
    IODIR0 |= 0x00ff0000; //ROWS as output    
    l=strlen(k);
    i2c_eeprom_page_write(I2C_EEPROM_SA,ADDRR,(u8*)k,l);
    i2c_eeprom_seq_read(I2C_EEPROM_SA,ADDRR,(u8*)dummy_buff,l);
    while(1)
  	{
		
		do
		{
		   display_char((unsigned char*)dummy_buff,1700);
		}while(r_flag==0);
  	// IODIR0 |= 0x00ff0000; // Set ROWS as output 
	while (1) {
        if (r_flag) {  
            r_flag = 0;  // Reset flag after receiving data
            
             len = strlen(buff);
            if (len > 0) {
                // Save received data to EEPROM
                i2c_eeprom_page_write(I2C_EEPROM_SA, ADDRR, (u8*)buff, len);
                delay_ms(500);  // Small delay for write completion
                
                // Read back the saved data
                i2c_eeprom_seq_read(I2C_EEPROM_SA, ADDRR, (u8*)dummy_buff, len);
                
                // Display received message on Dot Matrix
                display_char((unsigned char*)dummy_buff, 1700);
                
                // Send received data back via UART for debugging (Optional)
                UART0_Str("\nReceived: ");
                UART0_Str(dummy_buff);
            }

            // Clear buffers for new data
           memset(buff,'\0',100);
            memset(dummy_buff,'\0',100);
        }
    }
}
}
