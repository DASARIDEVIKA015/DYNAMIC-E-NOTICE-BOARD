

void InitUART0(void); 

void UART0_Tx(char ch);  

char UART0_Rx(void); 

void UART0_Str(char *);

