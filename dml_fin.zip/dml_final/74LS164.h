/* 74LS164.h */
void Init_74LS164(void);
void SIPO_74LS164(unsigned char );//Serial In Parallel Out(SIPO) Operations
void SIPO_74LS1641(unsigned char );
void SIPO_74LS1642(unsigned char );
void SIPO_74LS1643(unsigned char );

