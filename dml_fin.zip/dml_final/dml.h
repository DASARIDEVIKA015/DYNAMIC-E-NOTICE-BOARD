void display_char(unsigned char *ch,unsigned int delay);



