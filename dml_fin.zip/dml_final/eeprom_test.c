#include<lpc21xx.h>
#include"delay.h"
#include"types.h"
#include"lcd_defines.h"
#include "lcd.h"
#include "i2c.h"
#include "i2c_defines.h"
//#include "i2c_eeprom.h"
char str[100];
int main()
{
	Init_LCD();
	init_i2c();
	while(1)
	{
	cmdLCD(0x01);
	cmdLCD(0x80);
	strLCD("hello");
	i2c_eeprom_page_write(0x0050,0x0000,"@@786pavan",12);
	//delay_ms(100);																						    
	i2c_eeprom_seq_read(0x0050,0x0000,(u8*)str,12);
	//delay_ms(3000);
	cmdLCD(0xc0);
	strLCD(str);
	delay_ms(5000);
	}
}
